Bulk Postal Sender - unzip, pip install -r requirements.txt, set .env or env vars, python app.py
